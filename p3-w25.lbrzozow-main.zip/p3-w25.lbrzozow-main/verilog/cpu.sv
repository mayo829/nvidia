/////////////////////////////////////////////////////////////////////////
//                                                                     //
//   Modulename :  cpu.sv                                              //
//                                                                     //
//  Description :  Top-level module of the verisimple processor;       //
//                 This instantiates and connects the 5 stages of the  //
//                 Verisimple pipeline together.                       //
//                                                                     //
/////////////////////////////////////////////////////////////////////////

`include "sys_defs.svh"

module cpu (
    input clock, // System clock//
    input reset, // System reset

    input MEM_TAG   mem2proc_transaction_tag, // Memory tag for current transaction
    input MEM_BLOCK mem2proc_data,            // Data coming back from memory
    input MEM_TAG   mem2proc_data_tag,        // Tag for which transaction data is for

    output MEM_COMMAND proc2mem_command, // Command sent to memory
    output ADDR        proc2mem_addr,    // Address sent to memory
    output MEM_BLOCK   proc2mem_data,    // Data sent to memory
    output MEM_SIZE    proc2mem_size,    // Data size sent to memory

    // Note: these are assigned at the very bottom of the module
    output COMMIT_PACKET [`N-1:0] committed_insts,

    // Debug outputs: these signals are solely used for debugging in testbenches
    // Do not change for project 3
    // You should definitely change these for project 4
    output ADDR  if_NPC_dbg,
    output DATA  if_inst_dbg,
    output logic if_valid_dbg,
    output ADDR  if_id_NPC_dbg,
    output DATA  if_id_inst_dbg,
    output logic if_id_valid_dbg,
    output ADDR  id_ex_NPC_dbg,
    output DATA  id_ex_inst_dbg,
    output logic id_ex_valid_dbg,
    output ADDR  ex_mem_NPC_dbg,
    output DATA  ex_mem_inst_dbg,
    output logic ex_mem_valid_dbg,
    output ADDR  mem_wb_NPC_dbg,
    output DATA  mem_wb_inst_dbg,
    output logic mem_wb_valid_dbg
);

    //////////////////////////////////////////////////
    //                                              //
    //                Pipeline Wires                //
    //                                              //
    //////////////////////////////////////////////////

    // Pipeline register enables
    logic if_id_enable, id_ex_enable, ex_mem_enable, mem_wb_enable;

    // Outputs from IF-Stage and IF/ID Pipeline Register
    ADDR Imem_addr;
    IF_ID_PACKET if_packet, if_packet_mod, if_id_reg;

    // Outputs from ID stage and ID/EX Pipeline Register
    ID_EX_PACKET id_packet, id_packet_mod, id_ex_reg, id_ex_reg_mod;

    // Outputs from EX-Stage and EX/MEM Pipeline Register
    EX_MEM_PACKET ex_packet, ex_packet_mod, ex_mem_reg;

    // Outputs from MEM-Stage and MEM/WB Pipeline Register
    MEM_WB_PACKET mem_packet, mem_wb_reg;

    // Outputs from MEM-Stage to memory
    ADDR        Dmem_addr;
    MEM_BLOCK   Dmem_store_data;
    MEM_COMMAND Dmem_command;
    MEM_SIZE    Dmem_size;

    // Outputs from WB-Stage (These loop back to the register file in ID)
    COMMIT_PACKET wb_packet;

    //////////////////////////////////////////////////
    //                                              //
    //                Memory Outputs                //
    //                                              //
    //////////////////////////////////////////////////

    // these signals go to and from the processor and memory
    // we give precedence to the mem stage over instruction fetch
    // note that there is no latency in project 3
    // but there will be a 100ns latency in project 4

    always_comb begin
        if (Dmem_command != MEM_NONE) begin  // read or write DATA from memory
            proc2mem_command = Dmem_command;
            proc2mem_size    = Dmem_size;   // size is never DOUBLE in project 3
            proc2mem_addr    = Dmem_addr;
        end else begin                      // read an INSTRUCTION from memory
            proc2mem_command = MEM_LOAD;
            proc2mem_addr    = Imem_addr;
            proc2mem_size    = DOUBLE;      // instructions load a full memory line (64 bits)
        end
        proc2mem_data = Dmem_store_data;
    end

    //////////////////////////////////////////////////
    //                                              //
    //                  Valid Bit                   //
    //                                              //
    //////////////////////////////////////////////////

    // This state controls the stall signal that artificially forces IF
    // to stall until the previous instruction has completed.
    // For project 3, start by assigning if_valid to always be 1

    logic if_valid, start_valid_on_reset, wb_valid;


    always_ff @(posedge clock) begin
        // Start valid on reset. Other stages (ID,EX,MEM,WB) start as invalid
        // Using a separate always_ff is necessary since if_valid is combinational
        // Assigning if_valid = reset doesn't work as you'd hope :/
        start_valid_on_reset <= reset;
    end

    // valid bit will cycle through the pipeline and come back from the wb stage
    logic structural_hazard;
    assign structural_hazard = ex_mem_reg.valid && (ex_mem_reg.rd_mem || ex_mem_reg.wr_mem);
    // if struc/lw data hazard, stall
    logic lw_data_hazard;


    logic forward_from_mem_to_rs1, forward_from_mem_to_rs2, forward_from_wb_to_rs1, forward_from_wb_to_rs2, forward_from_ex_to_rs1, forward_from_ex_to_rs2;
    logic rs1_valid, rs2_valid;
    logic id_ex_to_ex_mem_valid, id_ex_to_mem_wb_valid; // is all data needed for data hazard check valid in pipeline regs?

    assign lw_data_hazard = (forward_from_ex_to_rs1 || forward_from_ex_to_rs2) && id_ex_reg.rd_mem;
    // assign if_valid = !(structural_hazard || lw_data_hazard) || start_valid_on_reset; // start_valid_on_reset || wb_valid;

    always_comb begin
        if_valid = 1;//start_valid_on_reset || wb_valid;

        if (lw_data_hazard || structural_hazard) begin
            if_valid = 0;
        end
    end

    //////////////////////////////////////////////////
    //                                              //
    //                  IF-Stage                    //
    //                                              //
    //////////////////////////////////////////////////

    stage_if stage_if_0 (
        // Inputs
        .clock (clock),
        .reset (reset),
        .if_valid      (if_valid),
        .take_branch   (ex_mem_reg.take_branch),
        .branch_target (ex_mem_reg.alu_result),
        .Imem_data     (mem2proc_data),

        // Outputs
        .if_packet (if_packet),
        .Imem_addr (Imem_addr)
    );

    // debug outputs
    assign if_NPC_dbg   = if_packet.NPC;
    assign if_inst_dbg  = if_packet.inst;
    assign if_valid_dbg = if_packet.valid;

    //////////////////////////////////////////////////
    //                                              //
    //            IF/ID Pipeline Register           //
    //                                              //
    //////////////////////////////////////////////////

    assign if_id_enable = (!lw_data_hazard) || ex_mem_reg.take_branch;

    always_ff @(posedge clock) begin
        if (reset) begin
            if_id_reg.inst  <= `NOP;
            if_id_reg.valid <= `FALSE;
            if_id_reg.NPC   <= 0;
            if_id_reg.PC    <= 0;
        end else if (if_id_enable) begin
            if_id_reg <= if_packet_mod;
        end
    end

    // debug outputs
    assign if_id_NPC_dbg   = if_id_reg.NPC;
    assign if_id_inst_dbg  = if_id_reg.inst;
    assign if_id_valid_dbg = if_id_reg.valid;

    //////////////////////////////////////////////////
    //                                              //
    //                  ID-Stage                    //
    //                                              //
    //////////////////////////////////////////////////

    stage_id stage_id_0 (
        // Inputs
        .clock (clock),
        .reset (reset),
        .if_id_reg       (if_id_reg),
        .wb_regfile_en   (wb_packet.valid),
        .wb_regfile_idx  (wb_packet.reg_idx),
        .wb_regfile_data (wb_packet.data),

        // Output
        .id_packet (id_packet)
    );

    //////////////////////////////////////////////////
    //                                              //
    //            ID/EX Pipeline Register           //
    //                                              //
    //////////////////////////////////////////////////

    assign id_ex_enable = 1;

    always_ff @(posedge clock) begin
        if (reset) begin
            id_ex_reg <= '{
                `NOP, // we can't simply assign 0 because NOP is non-zero
                32'b0, // PC
                32'b0, // NPC
                32'b0, // rs1 select
                32'b0, // rs2 select
                OPA_IS_RS1,
                OPB_IS_RS2,
                `ZERO_REG,
                ALU_ADD,
                1'b0, // mult
                1'b0, // rd_mem
                1'b0, // wr_mem
                1'b0, // cond
                1'b0, // uncond
                1'b0, // halt
                1'b0, // illegal
                1'b0, // csr_op
                1'b0  // valid
            };
        end else if (id_ex_enable) begin
            id_ex_reg <= id_packet_mod;
        end
    end

    // debug outputs
    assign id_ex_NPC_dbg   = id_ex_reg.NPC;
    assign id_ex_inst_dbg  = id_ex_reg.inst;
    assign id_ex_valid_dbg = id_ex_reg.valid;

    //////////////////////////////////////////////////
    //                                              //
    //                  EX-Stage                    //
    //                                              //
    //////////////////////////////////////////////////

    stage_ex stage_ex_0 (
        // Input
        .id_ex_reg (id_ex_reg_mod),

        // Output
        .ex_packet (ex_packet)
    );

    // data hazard logic
    
    assign rs1_valid = id_ex_reg.opa_select == OPA_IS_RS1;
    assign rs2_valid = id_ex_reg.opb_select == OPB_IS_RS2;
    assign id_ex_to_ex_mem_valid = id_ex_reg.valid && ex_mem_reg.valid && ex_mem_reg.dest_reg_idx != `ZERO_REG;
    assign id_ex_to_mem_wb_valid = id_ex_reg.valid && mem_wb_reg.valid && mem_wb_reg.dest_reg_idx != `ZERO_REG;

    assign if_id_to_id_ex_valid = if_id_reg.valid && id_ex_reg.valid && id_ex_reg.dest_reg_idx != `ZERO_REG;
    assign forward_from_ex_to_rs1 = (if_id_to_id_ex_valid && (if_id_reg.inst.r.rs1 == id_ex_reg.dest_reg_idx));
    assign forward_from_ex_to_rs2 = (if_id_to_id_ex_valid && (if_id_reg.inst.r.rs2 == id_ex_reg.dest_reg_idx));

    // check for hazard from mem stage (one stage ahead)
    assign forward_from_mem_to_rs1 = (id_ex_to_ex_mem_valid && (id_ex_reg.inst.r.rs1 == ex_mem_reg.dest_reg_idx));
    assign forward_from_mem_to_rs2 = (id_ex_to_ex_mem_valid && (id_ex_reg.inst.r.rs2 == ex_mem_reg.dest_reg_idx));

    // check for hazard from wb stage (two stages ahead)
    assign forward_from_wb_to_rs1 = (id_ex_to_mem_wb_valid && (id_ex_reg.inst.r.rs1 == mem_wb_reg.dest_reg_idx));
    assign forward_from_wb_to_rs2 = (id_ex_to_mem_wb_valid && (id_ex_reg.inst.r.rs2 == mem_wb_reg.dest_reg_idx));

    // lw data hazard if hazard from mem stage and is a lw
    
    // if lw data hazard, modify the ex_packet, else pass through

    // branch resolution
    always_comb begin
        if_packet_mod = if_packet;
        id_packet_mod = id_packet;
        ex_packet_mod = ex_packet;
        id_ex_reg_mod = id_ex_reg;

        // if branch taken, flush the pipeline
        if (ex_mem_reg.take_branch) begin
            if_packet_mod.inst = `NOP;
            if_packet_mod.valid = `FALSE;
            id_packet_mod.inst = `NOP;
            id_packet_mod.valid = `FALSE;
            // ex_packet_mod.inst = `NOP;
            ex_packet_mod.valid = `FALSE;
            ex_packet_mod.take_branch = 1'b0;
        end

        // if (lw_data_hazard && (forward_from_wb_to_rs1 || forward_from_wb_to_rs2)) begin
        //     if (forward_from_wb_to_rs1) begin
        //         id_packet_mod.rs1_value = mem_wb_reg.result;
        //     end else begin
        //         id_packet_mod.rs2_value = mem_wb_reg.result;
        //     end
        // end
        // if rs1 hazard, modify the id_ex_reg to forward data to rs1
        if (lw_data_hazard) begin
            id_packet_mod.valid = `FALSE;
            id_packet_mod.inst = `NOP;
        end

        if (forward_from_mem_to_rs1) begin
            if (ex_mem_reg.rd_mem) begin // if lw hazard
                ex_packet_mod.valid = `FALSE;
                id_ex_reg_mod.rs1_value = ex_mem_reg.alu_result;
            end else begin
                id_ex_reg_mod.rs1_value = ex_mem_reg.alu_result;
                // id_ex_reg_mod.opa_select = OPA_IS_RS1;
            end
        end else if (forward_from_wb_to_rs1) begin
            id_ex_reg_mod.rs1_value = mem_wb_reg.result;
            // id_ex_reg_mod.opa_select = OPA_IS_RS1;
        end

        // if rs2 hazard, modify the id_ex_reg to forward data to rs2
        if (forward_from_mem_to_rs2) begin
            if (ex_mem_reg.rd_mem) begin // if lw hazard
                ex_packet_mod.valid = `FALSE;
                id_ex_reg_mod.rs2_value = ex_mem_reg.alu_result;
            end else begin
                id_ex_reg_mod.rs2_value = ex_mem_reg.alu_result;
                // id_ex_reg_mod.opb_select = OPB_IS_RS2;
            end
        end else if (forward_from_wb_to_rs2) begin
            id_ex_reg_mod.rs2_value = mem_wb_reg.result;
            // id_ex_reg_mod.opb_select = OPB_IS_RS2;
        end
    end

    //////////////////////////////////////////////////
    //                                              //
    //           EX/MEM Pipeline Register           //
    //                                              //
    //////////////////////////////////////////////////

    assign ex_mem_enable = 1'b1;

    always_ff @(posedge clock) begin
        if (reset) begin
            ex_mem_inst_dbg <= `NOP; // debug output
            ex_mem_reg      <= 0;    // the defaults can all be zero!
        end else if (ex_mem_enable) begin
            ex_mem_inst_dbg <= id_ex_inst_dbg; // debug output, just forwarded from ID
            ex_mem_reg      <= ex_packet_mod;
        end
    end

    // debug outputs
    assign ex_mem_NPC_dbg   = ex_mem_reg.NPC;
    assign ex_mem_valid_dbg = ex_mem_reg.valid;

    //////////////////////////////////////////////////
    //                                              //
    //                 MEM-Stage                    //
    //                                              //
    //////////////////////////////////////////////////

    stage_mem stage_mem_0 (
        // Inputs
        .ex_mem_reg     (ex_mem_reg),
        .Dmem_load_data (mem2proc_data),

        // Outputs
        .mem_packet      (mem_packet),
        .Dmem_command    (Dmem_command),
        .Dmem_size       (Dmem_size),
        .Dmem_addr       (Dmem_addr),
        .Dmem_store_data (Dmem_store_data)
    );

    //////////////////////////////////////////////////
    //                                              //
    //           MEM/WB Pipeline Register           //
    //                                              //
    //////////////////////////////////////////////////

    assign mem_wb_enable = 1'b1;

    always_ff @(posedge clock) begin
        if (reset) begin
            mem_wb_inst_dbg <= `NOP; // debug output
            mem_wb_reg      <= 0;    // the defaults can all be zero!
        end else if (mem_wb_enable) begin
            mem_wb_inst_dbg <= ex_mem_inst_dbg; // debug output, just forwarded from EX
            mem_wb_reg      <= mem_packet;
        end
    end

    // debug outputs
    assign mem_wb_NPC_dbg   = mem_wb_reg.NPC;
    assign mem_wb_valid_dbg = mem_wb_reg.valid;

    //////////////////////////////////////////////////
    //                                              //
    //                  WB-Stage                    //
    //                                              //
    //////////////////////////////////////////////////

    stage_wb stage_wb_0 (
        // Input
        .mem_wb_reg (mem_wb_reg), // doesn't use all of these

        // Output
        .wb_packet (wb_packet)
    );

    // This signal is solely used by if_valid for the initial stalling behavior
    always_ff @(posedge clock) begin
        if (reset) wb_valid <= 0;
        else       wb_valid <= mem_wb_reg.valid;
    end

    //////////////////////////////////////////////////
    //                                              //
    //               Pipeline Outputs               //
    //                                              //
    //////////////////////////////////////////////////

    // Output the committed instruction to the testbench for counting
    assign committed_insts[0] = wb_packet;

endmodule // pipeline