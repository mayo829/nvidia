# test for all
    lw   x3, 0(x1)
    add  x3, x3, x4
    beq  x5, x4, duhh
    lw   x7, 4(x1)
    add  x8, x7, x9
duhh:
    sub  x20, x19, x18
    lw   x17, 8(x16)
    bne  x15, x14, duhh
    add  x13, x12, x11
    lw   x10, 12(x1)
    wfi