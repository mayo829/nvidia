data = 0x1000
    li	x4, data
    li	x5, 0x1008
    lw	x2, 0(x4)
    lw	x3, 0(x5)
    add	x3,	x3,	x2 #
    lw	x2, 0(x4)
    lw	x3, 0(x5)
    lw	x2, 0(x4)
    lw	x3, 0(x5)
    wfi