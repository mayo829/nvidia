# test for data forwarding
    add t1, t1, t1
    add t1, t1, t2
    add t1, t1, t2
    add t1, t1, t3
    add t1, t1, t2
    add t3, t3, t2
    add t3, t3, t3
    add t3, t3, t3
    add x3, x3, x3