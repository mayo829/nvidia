# test for control hazards (branches)
begin:  addi t0, t1, 5
start:  beq x0, x0, n1 # unconditional branch (branch taken)
        addi t0, t1, 5
        wfi # should skip
        addi t0, t1, 5
        addi t0, t1, 5
n1:     bne x0, x0, n2 # branch not taken
        addi t0, t1, 5
n2:     beq x0, x0, end # branch taken to end
        wfi
end:    wfi