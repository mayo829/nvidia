    data = 0x1000
    li	x2, data
    li	x6, data
    sw	x2, 0(x2)
    lw	x2, 0(x2)
    sw	x2, 0(x2)
    sw	x2, 0(x2)
    sw	x2, 0(x2)
    sw	x6, 0(x2)
    add	x2, x6, x2
    lw	x6, 0(x2)
    lw	x2, 0(x2)
    lw	x6, 0(x2)
    add	x2, x6, x2
    wfi